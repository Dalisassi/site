<?php
session_start();

if (isset($_SESSION['jdffJDHjdggf44'])){

    $_SESSION['jdffJDHjdggf44'] = array();

    session_destroy();

    header("Location: ../index.php");
}else{
    header("Location: ../login.php");

}
?>